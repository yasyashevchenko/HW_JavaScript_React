import React from 'react';
import './App.css';

import { ColorContainer } from "./components/MyComponents";


function App() {
  return (
    <div className="App">
      {}
      <ColorContainer />
      
    </div>
  );
}

export default App;
