export const BOTTON_COLOR = 'BOTTON_COLOR';
