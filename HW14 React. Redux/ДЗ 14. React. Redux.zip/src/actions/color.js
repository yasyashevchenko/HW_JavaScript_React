import { BOTTON_COLOR } from "../constants";

export const actionColor = (color) => ({
    type: BOTTON_COLOR,
    color: color
});